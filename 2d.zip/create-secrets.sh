#!/bin/bash

echo "Deleting isvaadmin Secret"
kubectl delete secret isvaadmin > /dev/null 2>&1
echo "Creating isvaadmin Secret"
kubectl create secret generic isvaadmin
kubectl patch secret/isvaadmin -p '{"data":{"adminpw":"UGFzc3cwcmQ="}}'

kubectl delete secret isva-secrets > /dev/null 2>&1
echo "Creating isvaadmin Secret"
kubectl create secret generic isva-secrets
kubectl patch secret/isva-secrets -p '{"data":{"adminpw":"UGFzc3cwcmQ="}}'

kubectl delete secret isva-admin > /dev/null 2>&1
echo "Creating isvaadmin Secret"
kubectl create secret generic isva-admin
kubectl patch secret/isva-admin -p '{"data":{"adminPassword":"UGFzc3cwcmQ="}}'




echo "Deleting configreader Secret"
kubectl delete secret configreader > /dev/null 2>&1
echo "Creating configreader Secret"
kubectl create secret generic configreader
kubectl patch secret/configreader -p '{"data":{"cfgsvcpw":"UGFzc3cwcmQ="}}'
echo "Done."
